import mongoose from "mongoose";

const shopSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    image:{
        type:String,
        required:true
    },
    owner:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },
    city:{
         type:String,
        required:true
    },
    state:{
         type:String,
        required:true
    },
    address:{
        type:String,
        required:true
    },
    // UPI payment details configured by owner
    upiVpa:{
        type:String,
        default:null
    },
    upiPayeeName:{
        type:String,
        default:null
    },
    items:[{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Item"
    }],
    isOpen:{
        type:Boolean,
        default:true
    }
    ,
    rating:{
        average:{type:Number,default:0},
        count:{type:Number,default:0}
    }

},{timestamps:true})

const Shop=mongoose.model("Shop",shopSchema)
export default Shop